N = 0
M = 0
classes = []
room_capacities = []

################
## Read Input ##
################
def read_input(file_name):
    global N, M, classes, room_capacities

    with open(file_name) as file:
        lines = [line.rstrip() for line in file]

    N, M = tuple(int(x) for x in lines[0].split())

    for i in range(N):
        classes.append(tuple(int(x) for x in lines[i + 1].split()))

    room_capacities = [int(x) for x in lines[-1].split()]

######################
## BEGIN Constraint ##
######################

def sp_constraint(sp, r, k=N):
    global N, M, classes, room_capacities

    for i in range(k):
        if sp[i] == -1:
            continue
        DC = int(sp[i] / 6) * 6
        if sp[i] + classes[i][0] > DC + 6:
            return False

    for i in range(k):
        if sp[i] == -1:
            continue
        for j in range(i+1, k):
            if sp[j] == -1:
                continue
            if classes[i][1] == classes[j][1]:
                start1 = sp[i]
                end1 = sp[i] + classes[i][0]
                start2 = sp[j]
                end2 = sp[j] + classes[j][0]

                if (start1 <= end2) and (end1 >= start2):
                    return False
            
    return True

def r_constraint(sp, r, k=N):
    global N, M, classes, room_capacities

    for i in range(k):
        if r[i] == -1:
            continue
        if classes[i][2] > room_capacities[r[i]]:
            return False
        
    for i in range(k):
        if r[i] == -1:
            continue
        for j in range(i+1, k):
            if r[j] == -1:
                continue
            if r[i] == r[j]:
                start1 = sp[i]
                end1 = sp[i] + classes[i][0]
                start2 = sp[j]
                end2 = sp[j] + classes[j][0]

                if (start1 <= end2) and (end1 >= start2):
                    return False

    return True

def sp_r_constraint(sp, r, k=N):
    global N, M, classes, room_capacities

    for i in range(k):
        if (sp[i] == -1) != (r[i] == -1):
            return False
    
    if not sp_constraint(sp, r, k):
        return False
    if not r_constraint(sp, r, k):
        return False
    
    return True

####################
## END Constraint ##
####################

#######################
## BEGIN Brute Force ##
#######################

MAX = 0
SP = []
R = []

def TRY(k, sp_candidates: set, r_candidates: set):
    global N, M, classes, room_capacities, sp, r, MAX, SP, R
    if k == N:
        # eval result
        temp = sum(map(lambda x: x>=0, sp))
        if temp > MAX:
            MAX = temp
            SP = sp.copy()
            R = r.copy()
            print("#########################################")
            
        return
    
    for sp_candidate in sp_candidates:
        sp[k] = sp_candidate

        if sum(map(lambda x: x>=0, sp[0:k+1])) + N - k - 1 <= MAX + 1:
            continue

        for r_candidate in r_candidates:
            r[k] = r_candidate
            if sp_r_constraint(sp, r, k):
                TRY(k+1, sp_candidates, r_candidates)
            r[k] = -1
        sp[k] = -1

#####################
## END Brute Force ##
#####################

if __name__ == "__main__":
    read_input('src/data/input0.txt')

    sp = [-1] * N # value = {-1} or range(0, 59)
    r = [-1] * N # value = {-1} or range(0, M-1)

    sp_candidates = set(range(-1, 60))
    r_candidates = set(range(-1, M))
 
    TRY(0, sp_candidates, r_candidates)

    print("RESULT")
    print(MAX)

    for i in range(N):
        tiet_bat_dau = SP[i]
        phong = R[i]
        thoi_luong = classes[i][0]
        gv = classes[i][1]
        si_so = classes[i][2]
        max_si_so = room_capacities[R[i]]

        if tiet_bat_dau != -1:
            print(f"id:{i}\t tbd:{tiet_bat_dau}\t tl:{thoi_luong}\t gv:{gv}\t p:{phong}\t ss:{si_so}\t mss:{max_si_so}")
